# mcp_server/adk_mcp_server.py

import asyncio
import json
import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Adjust the path to import tools from the 'tools' directory
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../tools')))

# Import MCP server components
from mcp import types as mcp_types
from mcp.server.lowlevel import Server, NotificationOptions
from mcp.server.models import InitializationOptions
import mcp.server.stdio

# Import ADK FunctionTool and conversion utility
from google.adk.tools.function_tool import FunctionTool
from google.adk.tools.mcp_tool.conversion_utils import adk_to_mcp_tool_type

# Import your custom tools
from tools.parse_input import parse_input
from tools.detect_lead import detect_lead
from tools.create_salesforce_lead import create_salesforce_lead

# Wrap functions as ADK tools
parse_input_tool = FunctionTool(parse_input)
detect_lead_tool = FunctionTool(detect_lead)
create_lead_tool = FunctionTool(create_salesforce_lead)

# Initialize MCP server
app = Server("leadsurge-mcp-server")

@app.list_tools()
async def list_tools() -> list[mcp_types.Tool]:
    """Advertise available tools to the MCP client."""
    print("[MCP] Listing tools...")
    tools = [
        adk_to_mcp_tool_type(parse_input_tool),
        adk_to_mcp_tool_type(detect_lead_tool),
        adk_to_mcp_tool_type(create_lead_tool)
    ]
    for tool in tools:
        print(f"[MCP] Advertised tool: {tool.name}")
    return tools

@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[mcp_types.TextContent | mcp_types.ImageContent | mcp_types.EmbeddedResource]:
    """Handle tool invocation requests from the MCP client."""
    tool_map = {
        parse_input_tool.name: parse_input_tool,
        detect_lead_tool.name: detect_lead_tool,
        create_lead_tool.name: create_lead_tool
    }

    if name in tool_map:
        try:
            print(f"[MCP] Invoking tool: {name} with arguments: {arguments}")
            result = await tool_map[name].run_async(args=arguments, tool_context=None)
            return [mcp_types.TextContent(type="text", text=json.dumps(result))]
        except Exception as e:
            print(f"[MCP] Error executing tool '{name}': {e}")
            return [mcp_types.TextContent(type="text", text=json.dumps({"error": str(e)}))]
    else:
        print(f"[MCP] Tool '{name}' not found.")
        return [mcp_types.TextContent(type="text", text=json.dumps({"error": f"Tool '{name}' not found."}))]

# Run the MCP server
async def run_server():
    print("[MCP] Starting MCP server...")
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name=app.name,
                server_version="1.0.0",
                capabilities=app.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

if __name__ == '__main__':
    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        print("\n[MCP] Server interrupted by user.")
    finally:
        print("[MCP] Server shutdown complete.")